"""Minimal runtime package for the Kaggle submission."""
