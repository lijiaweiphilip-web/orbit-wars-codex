# Submission

Stable Orbit Wars heuristic package with minimal runtime modules.

Params: experiments/swarm_probe_params.json
