Offline neural ranker branch. Do not submit unless gate report says SUBMIT CANDIDATE.
